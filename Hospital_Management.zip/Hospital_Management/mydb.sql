-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2016 at 12:25 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointmenr`
--

CREATE TABLE `appointmenr` (
  `p_Id` int(10) NOT NULL,
  `appID` int(10) NOT NULL,
  `pName` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `aTime` time NOT NULL,
  `docId` int(10) NOT NULL,
  `p_Id` int(10) NOT NULL,
  `aDate` date NOT NULL,
  `appID` int(10) NOT NULL,
  `pName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`aTime`, `docId`, `p_Id`, `aDate`, `appID`, `pName`) VALUES
('12:30:00', 11, 16, '2016-12-10', 1, 'abcd'),
('12:02:00', 11, 15, '2016-10-23', 2, 'Sharif'),
('12:30:00', 11, 15, '2016-12-01', 3, 'Sharif'),
('11:30:00', 11, 15, '2016-12-19', 4, 'Sharif');

-- --------------------------------------------------------

--
-- Table structure for table `completeorder`
--

CREATE TABLE `completeorder` (
  `PatientID` int(10) NOT NULL,
  `PatientName` varchar(50) NOT NULL,
  `ItemName` varchar(50) NOT NULL,
  `Quantity` int(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `SL` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `completeorder`
--

INSERT INTO `completeorder` (`PatientID`, `PatientName`, `ItemName`, `Quantity`, `Price`, `SL`) VALUES
(15, 'Sharif', 'Tushka', 2, 110, 7),
(15, 'Sharif', 'Napa', 3, 10, 9),
(15, 'Sharif', 'Adol', 1, 5, 13),
(15, 'Sharif', 'Salbutamol', 2, 380, 14),
(15, 'Sharif', 'Salbutamol', 1, 190, 15),
(15, 'Sharif', 'Tushka', 2, 110, 16),
(15, 'Sharif', 'Tushka', 1, 55, 17),
(15, 'Sharif', 'Tushka', 1, 55, 18),
(15, 'Sharif', 'Salbutamol', 1, 190, 19),
(15, 'Sharif', 'Salbutamol', 1, 190, 20),
(15, 'Sharif', 'Salbutamol', 1, 190, 21),
(15, 'Sharif', 'Salbutamol', 1, 190, 22),
(15, 'Sharif', 'Tushka', 1, 55, 23);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `docId` int(10) NOT NULL,
  `docName` varchar(50) NOT NULL,
  `Pass` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `docGender` varchar(50) NOT NULL,
  `Room` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Doc_Charge` varchar(50) NOT NULL,
  `DocUserName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`docId`, `docName`, `Pass`, `Department`, `docGender`, `Room`, `Phone`, `Doc_Charge`, `DocUserName`) VALUES
(11, 'Raiyan', '123456', 'Surgeons', 'Male', '224', '01681892768', 'Taka 1000', 'Raiyan1'),
(12, 'Ahmed', '12345', 'Neurologist', 'Male', '126', '01728919289', 'Tk 1500', 'Ahmed1'),
(13, 'sadlhk', 'jksadjh', 'Surgeons', 'Male', 'kjsdla', '923872319', 'Tk 200', 'jksahdl'),
(14, 'xyz', 'xyz', 'Cardiologist', 'Male', '7021', 'xyz', 'xyz', 'xyz'),
(15, 'jlksadfj', 'hsdk', 'Surgeons', 'Male', '3213', '9123840', '1000', 'lsadj');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `p_Id` int(10) NOT NULL,
  `pName` varchar(50) NOT NULL,
  `pPass` varchar(50) NOT NULL,
  `pAge` varchar(50) NOT NULL,
  `pGender` varchar(10) NOT NULL,
  `pAddress` varchar(200) NOT NULL,
  `pPhone` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `pUserName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`p_Id`, `pName`, `pPass`, `pAge`, `pGender`, `pAddress`, `pPhone`, `Department`, `pUserName`) VALUES
(15, 'Sharif', '123456', '23', 'Male', 'laisdhasdka', '0172329732', 'Surgeons', 'Sharif1'),
(16, 'abc', 'abc', '22', 'Male', 'abc', 'abc', 'Surgeons', 'abcd');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacyshow`
--

CREATE TABLE `pharmacyshow` (
  `ItemID` int(20) NOT NULL,
  `ItemName` varchar(50) NOT NULL,
  `Quantity` int(20) NOT NULL,
  `Price` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacyshow`
--

INSERT INTO `pharmacyshow` (`ItemID`, `ItemName`, `Quantity`, `Price`) VALUES
(1, 'Adol', 20, 5),
(2, 'Napa', 30, 10),
(3, 'Tushka', 99, 55),
(4, 'Salbutamol', 19, 190);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID` int(10) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Age` int(3) NOT NULL,
  `Gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID`, `Name`, `Age`, `Gender`) VALUES
(1, 'test01', 11, 'Female'),
(2, 'test02', 22, 'Male'),
(3, 'test03', 33, 'Female');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointmenr`
--
ALTER TABLE `appointmenr`
  ADD PRIMARY KEY (`appID`),
  ADD KEY `p_Id` (`p_Id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appID`);

--
-- Indexes for table `completeorder`
--
ALTER TABLE `completeorder`
  ADD PRIMARY KEY (`SL`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`docId`),
  ADD UNIQUE KEY `DocUserName` (`DocUserName`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`p_Id`),
  ADD UNIQUE KEY `pUserName` (`pUserName`);

--
-- Indexes for table `pharmacyshow`
--
ALTER TABLE `pharmacyshow`
  ADD PRIMARY KEY (`ItemID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointmenr`
--
ALTER TABLE `appointmenr`
  MODIFY `appID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `completeorder`
--
ALTER TABLE `completeorder`
  MODIFY `SL` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `docId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `p_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `pharmacyshow`
--
ALTER TABLE `pharmacyshow`
  MODIFY `ItemID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
