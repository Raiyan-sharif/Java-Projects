/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital_management;

import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author RAIYAN
 */
public class LoginPanel extends javax.swing.JFrame implements Icon{
    static String doctorID,patientID,patientName;
    DoctorSite doctorSiteObject;
    /**
     * Creates new form loginPanel
     */
    
    public LoginPanel() {
        initComponents();
         setIcon();
         setTitle();
         
         jPasswordFieldLoginPassword.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
          {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    String password=jPasswordFieldLoginPassword.getText();
                    String username=jTextFieldLoginUserName.getText();
                    String loginType = (String)jComboBoxLoginAs.getSelectedItem();

                    String q="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
                    String k="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
        
         
                    ResultSet r;
                    ResultSet v;
                    r = new DB().getTableData(q);
                    v = new DB().getTableData(k);
                    try {
                        if(loginType == "Doctor"){
                        if(r.next())
                        {

                            
                             try{
                                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                                Statement st = conn.createStatement();
                                String sql="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
                                ResultSet rs = st.executeQuery(sql);
                                //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                                while(rs.next())
                                {
                                    String col1 = rs.getString("docId");
                                    doctorID = col1;//Integer.parseInt(col1);
                                    //System.out.println(doctorID);
                                    dispose();
                                    new DoctorSite().setVisible(true);


                                }

                                }catch(Exception ex){
                                    JOptionPane.showMessageDialog(null, ex.getMessage());
                                }

                        }

                        else{
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");
                        }
                        }


                        else if(loginType == "Patient"){
                        if(v.next())
                        {
                            //JOptionPane.showMessageDialog(null, "Data found\n");
                            
                            try{
                                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                                Statement st = conn.createStatement();
                                String sql="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
                                ResultSet rs = st.executeQuery(sql);
                                //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                                while(rs.next())
                                {
                                    String col1 = rs.getString("p_Id");
                                    patientID =col1;// Integer.parseInt(col1);
                                    //System.out.println(patientID);
                                    dispose();
                                    new PatientSite().setVisible(true);

                                }

                                }catch(Exception ex){
                                    JOptionPane.showMessageDialog(null, ex.getMessage());
                                }

                        }
                        else{
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");
                        }
                        }
                        else if("".equals(username) && "".equals(password)){
                            JOptionPane.showMessageDialog(null,"Fill Both Text Field",null,JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");

                        }
                    } 
                    catch (SQLException ex) {
                        Logger.getLogger(LoginPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                      
                }
            }
        });
         jTextFieldLoginUserName.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
          {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    String password=jPasswordFieldLoginPassword.getText();
                    String username=jTextFieldLoginUserName.getText();
                    String loginType = (String)jComboBoxLoginAs.getSelectedItem();

                    String q="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
                    String k="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
        
         
                    ResultSet r;
                    ResultSet v;
                    r = new DB().getTableData(q);
                    v = new DB().getTableData(k);
                    try {
                        if(loginType == "Doctor"){
                        if(r.next())
                        {

                            
                             try{
                                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                                Statement st = conn.createStatement();
                                String sql="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
                                ResultSet rs = st.executeQuery(sql);
                                //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                                while(rs.next())
                                {
                                    String col1 = rs.getString("docId");
                                    doctorID = col1;//Integer.parseInt(col1);
                                    //System.out.println(doctorID);
                                    dispose();
                                    new DoctorSite().setVisible(true);


                                }

                                }catch(Exception ex){
                                    JOptionPane.showMessageDialog(null, ex.getMessage());
                                }

                        }

                        else{
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");
                        }
                        }


                        else if(loginType == "Patient"){
                        if(v.next())
                        {
                            //JOptionPane.showMessageDialog(null, "Data found\n");
                            
                            try{
                                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                                Statement st = conn.createStatement();
                                String sql="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
                                ResultSet rs = st.executeQuery(sql);
                                //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                                while(rs.next())
                                {
                                    String col1 = rs.getString("p_Id");
                                    patientID = col1;//Integer.parseInt(col1);
                                    //System.out.println(patientID);
                                    dispose();
                                    new PatientSite().setVisible(true);


                                }

                                }catch(Exception ex){
                                    JOptionPane.showMessageDialog(null, ex.getMessage());
                                }

                        }
                        else{
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");
                        }
                        }
                        else if("".equals(username) && "".equals(password)){
                            JOptionPane.showMessageDialog(null,"Fill Both Text Field",null,JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");

                        }
                    } 
                    catch (SQLException ex) {
                        Logger.getLogger(LoginPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
        
                      
                }
            }
        });
        jButtonLogin.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
          {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    String password=jPasswordFieldLoginPassword.getText();
                    String username=jTextFieldLoginUserName.getText();
                    String loginType = (String)jComboBoxLoginAs.getSelectedItem();

                    String q="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
                    String k="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
        
         
                    ResultSet r;
                    ResultSet v;
                    r = new DB().getTableData(q);
                    v = new DB().getTableData(k);
                    try {
                        if(loginType == "Doctor"){
                        if(r.next())
                        {

                            
                             try{
                                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                                Statement st = conn.createStatement();
                                String sql="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
                                ResultSet rs = st.executeQuery(sql);
                                //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                                while(rs.next())
                                {
                                    String col1 = rs.getString("docId");
                                    doctorID = col1;//Integer.parseInt(col1);
                                    //System.out.println(doctorID);
                                    dispose();
                                    new DoctorSite().setVisible(true);


                                }

                                }catch(Exception ex){
                                    JOptionPane.showMessageDialog(null, ex.getMessage());
                                }

                        }

                        else{
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");
                        }
                        }


                        else if(loginType == "Patient"){
                        if(v.next())
                        {
                            //JOptionPane.showMessageDialog(null, "Data found\n");
                            
                            try{
                                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                                Statement st = conn.createStatement();
                                String sql="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
                                ResultSet rs = st.executeQuery(sql);
                                //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                                while(rs.next())
                                {
                                    String col1 = rs.getString("p_Id");
                                    patientID = col1;//Integer.parseInt(col1);
                                    //System.out.println(patientID);
                                    dispose();
                                    new PatientSite().setVisible(true);


                                }

                                }catch(Exception ex){
                                    JOptionPane.showMessageDialog(null, ex.getMessage());
                                }

                        }
                        else{
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");
                        }
                        }
                        else if("".equals(username) && "".equals(password)){
                            JOptionPane.showMessageDialog(null,"Fill Both Text Field",null,JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                            jTextFieldLoginUserName.setText("");
                            jPasswordFieldLoginPassword.setText("");

                        }
                    } 
                    catch (SQLException ex) {
                        Logger.getLogger(LoginPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
            
         
                }
            }
        });
        jButtonSignUp.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
            {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    dispose();
                    new SignUp().setVisible(true);
                }
                    
            }
        });
        jButtonBack.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
            {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    dispose();
                    new Welcome().setVisible(true);
                }
                    
            }
        });
       }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextFieldLoginUserName = new javax.swing.JTextField();
        jPasswordFieldLoginPassword = new javax.swing.JPasswordField();
        jButtonLogin = new javax.swing.JButton();
        jButtonSignUp = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jComboBoxLoginAs = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jButtonBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 0, 0));

        jTextFieldLoginUserName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldLoginUserNameActionPerformed(evt);
            }
        });

        jPasswordFieldLoginPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordFieldLoginPasswordActionPerformed(evt);
            }
        });

        jButtonLogin.setText("Login");
        jButtonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLoginActionPerformed(evt);
            }
        });

        jButtonSignUp.setText("Sign Up");
        jButtonSignUp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSignUpActionPerformed(evt);
            }
        });

        jLabel1.setText("User Name:");

        jLabel2.setText("Password:");

        jLabel3.setText("New in this application?");

        jComboBoxLoginAs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Doctor", "Patient" }));

        jLabel4.setText("Login As:");

        jButtonBack.setText("Back");
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(37, 37, 37)
                                .addComponent(jButtonSignUp))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4))
                                .addGap(45, 45, 45)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jComboBoxLoginAs, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextFieldLoginUserName, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                                    .addComponent(jPasswordFieldLoginPassword)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(jButtonLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButtonBack)
                        .addGap(161, 161, 161)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jButtonBack)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldLoginUserName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jPasswordFieldLoginPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxLoginAs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(23, 23, 23)
                .addComponent(jButtonLogin)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jButtonSignUp))
                .addGap(39, 39, 39))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSignUpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSignUpActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new SignUp().setVisible(true);
    }//GEN-LAST:event_jButtonSignUpActionPerformed

    private void jTextFieldLoginUserNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldLoginUserNameActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_jTextFieldLoginUserNameActionPerformed

    private void jButtonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLoginActionPerformed
        // TODO add your handling code here:
        String password=jPasswordFieldLoginPassword.getText();
        String username=jTextFieldLoginUserName.getText();
        String loginType = (String)jComboBoxLoginAs.getSelectedItem();
                
        String q="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
        String k="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
        //String q1="SELECT docId FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
        //String k2="SELECT p_Id patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
         
        //System.out.println(q);
        
        //ResultSet p;
        ResultSet r;
        ResultSet v;
        r = new DB().getTableData(q);
        v = new DB().getTableData(k);
            try {
                if(loginType == "Doctor"){
                if(r.next())
                {
                    
                    
                     try{
                        Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                        Statement st = conn.createStatement();
                        String sql="SELECT * FROM doctor WHERE DocUserName='"+username+ "'and Pass='"+password+"'";
                        ResultSet rs = st.executeQuery(sql);
                        //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                        while(rs.next())
                        {
                            String col1 = rs.getString("docId");
                            this.doctorID = col1;//Integer.parseInt(col1);
                            //System.out.println(doctorID);
                            //doctorSiteObject.setDoctorID(doctorID);
                            this.dispose();
                            new DoctorSite().setVisible(true);


                        }
          
                        }catch(Exception ex){
                            JOptionPane.showMessageDialog(null, "error");
                        }
                   
                }
                
                else{
                    JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                    jTextFieldLoginUserName.setText("");
                    jPasswordFieldLoginPassword.setText("");
                }
                }
                
                
                else if(loginType == "Patient"){
                if(v.next())
                {
                    //JOptionPane.showMessageDialog(null, "Data found\n");
                    
                    try{
                        Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
                        Statement st = conn.createStatement();
                        String sql="SELECT * FROM patient WHERE pUserName='"+username+ "'and pPass='"+password+"'";
                        ResultSet rs = st.executeQuery(sql);
                        //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
                        while(rs.next())
                        {
                            String col1 = rs.getString("p_Id");
                            patientID = col1;//Integer.parseInt(col1);
                            //System.out.println(patientID);
                            this.dispose();
                            new PatientSite().setVisible(true);


                        }
          
                        }catch(Exception ex){
                            JOptionPane.showMessageDialog(null, "Wrong");
                        }
                    
                }
                else{
                    JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                    jTextFieldLoginUserName.setText("");
                    jPasswordFieldLoginPassword.setText("");
                }
                }
                else if("".equals(username) && "".equals(password)){
                    JOptionPane.showMessageDialog(null,"Fill Both Text Field",null,JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"The User Name or Password or user type is wrong try again",null,JOptionPane.ERROR_MESSAGE);
                    jTextFieldLoginUserName.setText("");
                    jPasswordFieldLoginPassword.setText("");
                    
                }
            } 
            catch (SQLException ex) {
                Logger.getLogger(LoginPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
            
         /*try{
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
            Statement st = conn.createStatement();
            String sql="SELECT * FROM patient";
            ResultSet rs = st.executeQuery(sql);
            //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
            while(rs.next())
            {
                String col1 = rs.getString("docId");
                doctorID = Integer.parseInt(col1);
                              
               
            }
          
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
            
         /*try{
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
            Statement st = conn.createStatement();
            String sql="SELECT * FROM patient";
            ResultSet rs = st.executeQuery(sql);
            //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
            while(rs.next())
            {
                String col1 = rs.getString("docId");
                doctorID = Integer.parseInt(col1);
                              
               
            }
          
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }*/
        
    }//GEN-LAST:event_jButtonLoginActionPerformed

    private void jPasswordFieldLoginPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordFieldLoginPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordFieldLoginPasswordActionPerformed

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new Welcome().setVisible(true);
    }//GEN-LAST:event_jButtonBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginPanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonBack;
    private javax.swing.JButton jButtonLogin;
    private javax.swing.JButton jButtonSignUp;
    private javax.swing.JComboBox<String> jComboBoxLoginAs;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPasswordField jPasswordFieldLoginPassword;
    private javax.swing.JTextField jTextFieldLoginUserName;
    // End of variables declaration//GEN-END:variables

    public void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("images.jpg")));
    }

    @Override
    public void setTitle() {
        setTitle("Login Page");
    }
    String getDoctorId(){
        return doctorID;
    }
    String getPatientId(){
        return patientID;
    }
    void setDoctorId(String a){
        this.doctorID = a;
    }
    void setPatientId(String b){
        this.patientID = b;
    }
}
