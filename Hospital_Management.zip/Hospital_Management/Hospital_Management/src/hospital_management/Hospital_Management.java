/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital_management;

/**
 *
 * @author RAIYAN
 */
interface Icon{
       void setIcon();
       void setTitle();

}
public class Hospital_Management {
    //static LoginPanel l= new LoginPanel();
    //static DoctorSite d = new DoctorSite();
    //static String b = l.getDoctorId();
    //d.setDoctorID(b);
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new Welcome().setVisible(true);
        //d.setDoctorID(b);
        
    }
    
}
      