/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital_management;

import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author RAIYAN
 */
public class AppointmentList extends javax.swing.JFrame implements Icon{

    /**
     * Creates new form appointmentList
     */
    DoctorSite doctorSiteObject = new DoctorSite();
    String doctorID = doctorSiteObject.getDoctorID();
    String doctorName,doctorDepartment;
    String time,date,patientID,patientName;
    DateFormat df = new SimpleDateFormat("YYYY-MM-DD"); 
    String date2 = "06/27/2007";
    
    public AppointmentList() {
        initComponents();
        setIcon();
        setTitle();
        getTableData();
        /*
        Date date1 = new Date();
        System.out.println(date1);
        System.out.println(df.format(date1));
        Date startDate = df.parse(date2);
        if(date1.before(startDate)){
            System.out.println("printed: "+df.format(date1));
        }*/
        
        jButtonBack.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
            {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    dispose();
                    new DoctorSite().setVisible(true);
                }
                    
            }
        });
        jButtonAppoint.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
            {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    if(jTableAppointmentList.getSelectedRow()==-1){
                        if(jTableAppointmentList.getSelectedRow()==0){
                            jLabelMessage.setText("Table is empty!!");
                        }
                        else{
                             jLabelMessage.setText("Table is empty or unselected");
                        }
                    }
                    if(jTextFieldPatientID.equals("") || jTextFieldTime.equals("HH:MM:SS") || jTextFieldDate.equals("YYYY-MM-DD")){
                        jLabelMessage.setText("Fill all the fiels");
                    }

                    else{
                        int selectedRowIndex = jTableAppointmentList.getSelectedRow();
                        patientName = jTableAppointmentList.getModel().getValueAt(selectedRowIndex, 0).toString();
                        patientID = jTableAppointmentList.getModel().getValueAt(selectedRowIndex, 1).toString();
                        time = jTextFieldTime.getText();
                        date = jTextFieldDate.getText();
                        theQuery("insert into appointmenr (`aTime`, `docId`, `p_Id`, `aDate`)values('"+time+"','"+doctorID+"','"+patientID+"','"+date+"'"+")");

                    };
                    
                }
                    
            }
        });
        jButtonDone.addKeyListener(new KeyAdapter()
        {       
            @Override
            public void keyPressed(KeyEvent e)
            {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                    int selectedRowIndex = jTableAppointmentList.getSelectedRow();
              theQuery("delete from appointmenr where p_Id="+jTableAppointmentList.getModel().getValueAt(selectedRowIndex, 1));  
                }
                    
            }
        });
        
       // System.out.println(doctorID);
    }
    private void getTableData(){
        Connection conn = null;
        Statement st = null;
        try{
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
            st = conn.createStatement();
            String sql="SELECT * FROM doctor WHERE docId='"+doctorID+"'";
            ResultSet rs = st.executeQuery(sql);
            //DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Gender"}, 0);
            while(rs.next())
            {
                String col1 = rs.getString("docName");
                String col2 = rs.getString("Department");
                doctorName= col1;
                doctorDepartment= col2;
               // model.addRow(new Object[]{col1, col2, col3, col4});
            }
           // jTableUsers.setModel(model);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
        try{
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
            st = conn.createStatement();
            String sql="SELECT * FROM appointmenr WHERE department='"+doctorDepartment+"'";
            ResultSet rs = st.executeQuery(sql);
            DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Name", "Patient ID"}, 0);
            while(rs.next())
            {
                String col1 = rs.getString("pName");
                String col2 = rs.getString("p_Id");
                //String col3 = rs.getString("Age");                
                //String col4 = rs.getString("Gender");                
                model.addRow(new Object[]{col1, col2});
            }
            jTableAppointmentList.setModel(model);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
        try{
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
            st = conn.createStatement();
            String sql="SELECT * FROM appointment WHERE docId='"+doctorID+"'";
            ResultSet rs = st.executeQuery(sql);
            DefaultTableModel model = new DefaultTableModel(new String[]{"Patient Id", "Patient Name","Appointed Date", "Appointed Time"}, 0);
            while(rs.next())
            {
                String col1 = rs.getString("p_id");
                String col2 = rs.getString("pName");
                String col3 = rs.getString("aDate");
                String col4 = rs.getString("aTime");
                                
                model.addRow(new Object[]{col1, col2,col3,col4});
            }
            jTableAppointedList.setModel(model);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    
    }
    public void theQuery(String query){
        Connection conn = null;
        Statement st =null;
        try{
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb","root","");
            st = conn.createStatement();
            st.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "done.");
            refreshMethod();
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    private void refreshMethod(){
        //jTID.setEditable(true);
        jLabelMessage.setText("");
        jTextFieldPatientID.setText("");
        jTextFieldTime.setText("HH:MM:SS");
        jTextFieldDate.setText("YYYY-MM-DD");
        //jCBGender.setSelectedItem("Male");
        getTableData(); 
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableAppointmentList = new javax.swing.JTable();
        jTextFieldPatientID = new javax.swing.JTextField();
        jTextFieldTime = new javax.swing.JTextField();
        jTextFieldDate = new javax.swing.JTextField();
        jButtonAppoint = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabelMessage = new javax.swing.JLabel();
        jButtonBack = new javax.swing.JButton();
        jButtonDone = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableAppointedList = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButtonClearHistory = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTableAppointmentList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Patient Name", "Patient Id"
            }
        ));
        jScrollPane1.setViewportView(jTableAppointmentList);

        jTextFieldTime.setText("HH:MM:SS");
        jTextFieldTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldTimeActionPerformed(evt);
            }
        });

        jTextFieldDate.setText("YYYY-MM-DD");

        jButtonAppoint.setText("Appointed");
        jButtonAppoint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAppointActionPerformed(evt);
            }
        });

        jLabel2.setText("Patient ID");

        jLabel3.setText("Time");
        jLabel3.setToolTipText("");

        jLabel4.setText("Date");

        jButtonBack.setText("Back");
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });

        jButtonDone.setText("done");
        jButtonDone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDoneActionPerformed(evt);
            }
        });

        jTableAppointedList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Patient Id", "Patient Name", "Appointed Date", "Appointed Time"
            }
        ));
        jScrollPane2.setViewportView(jTableAppointedList);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 255));
        jLabel1.setText("Appointed List:");

        jButtonClearHistory.setText("Clear History");
        jButtonClearHistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonClearHistoryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextFieldPatientID)
                            .addComponent(jTextFieldTime, javax.swing.GroupLayout.DEFAULT_SIZE, 67, Short.MAX_VALUE)
                            .addComponent(jTextFieldDate, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(91, 91, 91)
                                .addComponent(jButtonDone))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButtonAppoint, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButtonClearHistory, javax.swing.GroupLayout.Alignment.TRAILING))))))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(69, 69, 69)
                        .addComponent(jLabelMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButtonBack)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(170, 170, 170))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabelMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButtonBack)
                    .addComponent(jLabel1))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldPatientID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)
                            .addComponent(jButtonDone))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldTime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonAppoint)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldDate)
                            .addComponent(jLabel4)
                            .addComponent(jButtonClearHistory))
                        .addContainerGap())
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldTimeActionPerformed

    private void jButtonAppointActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAppointActionPerformed
        // TODO add your handling code here:
    if(jTableAppointmentList.getSelectedRow()==-1){
        if(jTableAppointmentList.getSelectedRow()==0){
            jLabelMessage.setText("Table is empty!!");
        }
        else{
             jLabelMessage.setText("Table is empty or unselected");
        }
    }
    if(jTextFieldPatientID.equals("") || jTextFieldTime.equals("HH:MM:SS") || jTextFieldDate.equals("YYYY-MM-DD")){
        jLabelMessage.setText("Fill all the fiels");
    }
    
    else{
        int selectedRowIndex = jTableAppointmentList.getSelectedRow();
        patientName = jTableAppointmentList.getModel().getValueAt(selectedRowIndex, 0).toString();
        patientID = jTableAppointmentList.getModel().getValueAt(selectedRowIndex, 1).toString();
        time = jTextFieldTime.getText();
        date = jTextFieldDate.getText();
        
        theQuery("insert into appointment (`aTime`, `docId`, `p_Id`, `aDate`, `pName`)values('"+time+"','"+doctorID+"','"+patientID+"','"+date+"','"+patientName+"'"+")");
       
    }    
    }//GEN-LAST:event_jButtonAppointActionPerformed

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackActionPerformed
        // TODO add your handling code here:
        this.dispose();
        new DoctorSite().setVisible(true);
    }//GEN-LAST:event_jButtonBackActionPerformed

    private void jButtonDoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDoneActionPerformed
        // TODO add your handling code here:
        int selectedRowIndex = jTableAppointmentList.getSelectedRow();
        theQuery("delete from appointmenr where p_Id="+jTableAppointmentList.getModel().getValueAt(selectedRowIndex, 1));
        getTableData();
    }//GEN-LAST:event_jButtonDoneActionPerformed

    private void jButtonClearHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonClearHistoryActionPerformed
        // TODO add your handling code here:
        theQuery("delete from `appointment`");
        getTableData();
    }//GEN-LAST:event_jButtonClearHistoryActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AppointmentList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AppointmentList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AppointmentList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AppointmentList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AppointmentList().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAppoint;
    private javax.swing.JButton jButtonBack;
    private javax.swing.JButton jButtonClearHistory;
    private javax.swing.JButton jButtonDone;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelMessage;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableAppointedList;
    private javax.swing.JTable jTableAppointmentList;
    private javax.swing.JTextField jTextFieldDate;
    private javax.swing.JTextField jTextFieldPatientID;
    private javax.swing.JTextField jTextFieldTime;
    // End of variables declaration//GEN-END:variables

    public void setIcon() {
           setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("images.jpg")));
    }

    @Override
    public void setTitle() {
        setTitle("Appointment List");
    }
    
}
